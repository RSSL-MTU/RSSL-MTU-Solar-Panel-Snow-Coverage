# snow coverage augmentation DS > 2025-04-24 1:43pm
https://universe.roboflow.com/searchandrescue-kkiyd/snow-coverage-augmentation-ds

Provided by a Roboflow user
License: CC BY 4.0

